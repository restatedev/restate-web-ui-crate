import{w as o}from"./with-props-CfcMxgCD.js";import{w as e}from"./chunk-AYJ5UCUI-BKPWG2A4.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
