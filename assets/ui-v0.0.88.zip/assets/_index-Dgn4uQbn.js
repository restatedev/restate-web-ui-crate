import{w as o}from"./with-props-oXzkBkcZ.js";import{x as e}from"./chunk-AYJ5UCUI-CB0tg21j.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
