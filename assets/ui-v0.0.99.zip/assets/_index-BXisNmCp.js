import{D as e,A as o}from"./chunk-C37GKA54-BJXt4x7q.js";const r=()=>e("/overview"),n=o(()=>null);export{r as clientLoader,n as default};
