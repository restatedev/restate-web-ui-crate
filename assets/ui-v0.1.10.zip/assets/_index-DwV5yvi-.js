import{D as e,z as o}from"./chunk-B7RQU5TL-BUqgvXP6.js";const r=()=>e("/overview"),n=o(()=>null);export{r as clientLoader,n as default};
