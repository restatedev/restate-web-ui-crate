import{y as o,D as t}from"./chunk-EPOLDU6W-DvSVeGZi.js";const s=({request:e})=>{const r=new URL(e.url);return t(`/overview${r.search}`)},a=o(()=>null);export{s as clientLoader,a as default};
