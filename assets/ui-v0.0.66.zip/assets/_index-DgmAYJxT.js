import{w as o}from"./with-props-cTPu4JMB.js";import{w as e}from"./chunk-AYJ5UCUI-d-6lkODS.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
