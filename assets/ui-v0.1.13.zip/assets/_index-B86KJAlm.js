import{y as o,D as t}from"./chunk-OIYGIGL5-BQwnj-SX.js";const s=({request:e})=>{const r=new URL(e.url);return t(`/overview${r.search}`)},a=o(()=>null);export{s as clientLoader,a as default};
