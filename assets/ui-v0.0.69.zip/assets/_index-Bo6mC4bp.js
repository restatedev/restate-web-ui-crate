import{w as o}from"./with-props-BK9MChb9.js";import{w as e}from"./chunk-AYJ5UCUI-B8jmbL4R.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
