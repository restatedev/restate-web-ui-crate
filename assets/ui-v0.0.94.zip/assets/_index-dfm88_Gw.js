import{w as o}from"./with-props-B5-ccywr.js";import{z as e}from"./chunk-AYJ5UCUI-Dy8zemgn.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
