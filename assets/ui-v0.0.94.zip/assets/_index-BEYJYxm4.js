import{G as e,z as o}from"./chunk-C37GKA54-DqeQxh3X.js";const r=()=>e("/overview"),n=o(()=>null);export{r as clientLoader,n as default};
