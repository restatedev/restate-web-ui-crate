import{w as o,B as t}from"./chunk-KS7C4IRE-DJnl3LSy.js";const s=({request:e})=>{const r=new URL(e.url);return t(`/overview${r.search}`)},a=o(()=>null);export{s as clientLoader,a as default};
