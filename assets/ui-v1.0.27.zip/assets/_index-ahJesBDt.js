import{w as o,C as t}from"./chunk-KS7C4IRE-Bp7rYUpI.js";const s=({request:e})=>{const r=new URL(e.url);return t(`/overview${r.search}`)},a=o(()=>null);export{s as clientLoader,a as default};
