import{w as o}from"./with-props--rRnElL1.js";import{w as e}from"./chunk-XJI4KG32-Bq3tSe0t.js";const i=()=>e("/overview"),n=o(()=>null);export{i as clientLoader,n as default};
